print("Hello World")
if 5 > 2:
    print("Five is greater than two")
"""this is 
multiline docstring"""
print("Hello, World!")
x = 5
y = "John"
print(x)
print(y)
x = 4
x = "Sally"
print(x)
x = "awesome"
print("Python is " + x)
x = 5
y = 10  # type: int
print(x + y)
#x = 5  # type: int
#y = "John"
#print(x + y)
x = 1
y = 2.8
z = 1j
print(type(x))
print(type(y))
print(type(z))
x = 1
y = 5461541211
z = -215451
print(type(x))
print(type(y))
print(type(z))
k = 35e3
print(type(k))
x = int(1)
y = int(5651515)
print(x)
print(y)
print(type(y))
x = float(1)
print(x)
y = str(2)
print(y)
print(type(y))
a = "hello"
print(a[0])
a = " Hello, World "
print(a.strip())
print(len(a))
print(a.upper())
print(a.replace("H","J"))
print(a.split(","))
#print("Enter your name: ")
#txt = raw_input()
#print("Hello, " + txt)
x = 5
x += 3
print(x)
x -= 3
print(x)
x *= 3
print(x)
x /= 3
print(x)
x %= 3
print(x)
x //= 3
print(x)
x = 5
x &= 3
print(x)
print(x< 5 and   x < 10)
print(x< 5 or   x < 10)
print (not(x< 5 and   x < 10))
x = ("Apple", "Banana")
print("Banana" in x)
thislist = ["apple", "Banana","Cherry"]
print(thislist)
thislist[1] = "Black Current"
print(thislist)
thislist = list(("apple", "Banana","Cherry"))
print(thislist)
thislist.append("damson")
print(thislist)
thislist.remove("damson")
print(thislist)
print(len(thislist))
thistuple = ("apple", "Banana", "Cherry")
print(thistuple)
print(thistuple[1])
#thistuple[1] = "Blackcurrent"
#print(thistuple)
thisset = {"Apple", "Banana"}
print(thisset)
thisset = set(("apple", "Banana", "Cherry"))
print(thisset)
thisset.add("Damson")
print(thisset)
thisset.remove("apple")
print(thisset)
print(len(thisset))
thisdict = {
    "Apple" : "Green",
    "Banana" : "Yellow",
    "Cherry" : "Red"
}
print(thisdict)
thisdict["Apple"] = "Red"
print(thisdict)
thisdict = dict(Apple = "Green", Banana = "Yellow", Cherry = "Red")
print(thisdict)
thisdict["Damson"] = "Purple"
print(thisdict)
del(thisdict["Banana"])
print(thisdict)
print(len(thisdict))
a = 33
b = 200
if a < b :
    print("a is greater than b")
a = 33
b = 33
if b>a:
    print("b is greater than a")
elif a==b:
    print("a is equal to b")

a = 200
b = 33
if b > a:
    print("b is greater than a")
elif a == b:
    print("a is equal to b")
else:
    print("a is greater than b")
i = 1
while i < 6:
    print(i)
    i += 1
i = 1
while i < 6:
    print(i)
    if i == 3:
        break
    i += 1
i = 0
while i < 6:
    i += 1
    if i == 3:
        continue
    print(i)

fruits = ["Apple", "Banana", "cherry"]
for x in fruits:
    print(x)
for x in range(6):
    print(x)
for x in range(2,30,5):
    print(x)
