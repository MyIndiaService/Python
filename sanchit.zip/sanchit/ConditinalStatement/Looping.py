def pattern3():
    for i in range(5, 1, -1):
        print("Row: " + str(i))
        for j in range(3, 1, -1):
            print(i)

        print("\n")


pattern3()
