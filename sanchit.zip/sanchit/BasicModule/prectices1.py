def my_function () :
    print("Hello from a function")
my_function()

def my_function(fname):
    print(fname + "refsnes")
my_function(" Emil ")
my_function(" tobias ")
my_function(" Linus ")
def my_function(country = "Norway"):
    print("I am from " + country)
my_function("Sweden")
my_function("India")
my_function()
def my_function(x):
    return 5 * x

print(my_function(3))
myfunc = lambda i:i*2
print(myfunc(8))

def sequential_search(dlist,item):

    pos = 0
    found = False
    while pos < len(dlist) and not found:
        if dlist[pos] == item:
            found = True
        else :
            pos = pos + 1
    return found, pos
print(sequential_search([11,23,58,56,77,43,12,65,19],31))

