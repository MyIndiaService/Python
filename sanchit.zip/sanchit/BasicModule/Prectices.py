item_one = 15
item_two = 25
item_three = 35
total = item_one + \
    item_two + \
    item_three
print(total)
a = range(11,0,-2)
print(a)
b = range(20)
print(b)