def sequential_search(dlist, item):

    pos = 0
    count = 0
    sum = 0
    total = 0
    found = False
    while pos < len(dlist):
        if dlist[pos] == item:
            found = True
            sum = sum + item
            count = count + 1
        total = total + dlist[pos]
        pos = pos + 1
    return found, count, sum, total


f, c, i, t = sequential_search([11, 23, 15, 31, 56, 31, 43, 12, 31, 19], 31)
if f:
    print("Given item is found ", c, "times and total is ", i, "out of ", t)
else:
    print("Given item is not available in the list ", c, "times and total is ", i, "out of ", t)
